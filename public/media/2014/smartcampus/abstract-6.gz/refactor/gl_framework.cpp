/*
 * CS475/CS675 - Computer Graphics
 *	ToyLOGO Assignment Base Code
 *
 * Copyright 2009-2014, Parag Chaudhuri, Department of CSE, IIT Bombay
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.	If not, see <http://www.gnu.org/licenses/>.
*/

#include "gl_framework.hpp"

namespace csX75
{
	int win_width;
	int win_height;

	//! Initialize GL State
	void initGL(void)
	{
		glClearDepth(1.0);
		//Set depth test to less-than
		glDepthFunc(GL_LESS);
		//Enable depth testing
		glEnable(GL_DEPTH_TEST);
		glEnable(GL_DEPTH_BUFFER_BIT); 
		
		//glEnable(GL_TEXTURE_2D);
		
		glMatrixMode(GL_PROJECTION);
		//Enable Gourard shading
		// glShadeModel(GL_SMOOTH);
		// glEnable(GL_BLEND);
		// glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();				// Reset The Projection Matrix
		
		gluPerspective(50,1, 0.1, 1000);
		glMatrixMode(GL_MODELVIEW);

	}


	//!GLFW Error Callback
	void error_callback(int error, const char* description)
	{
		std::cerr<<description<<std::endl;
	}

	//!GLFW framebuffer resize callback
	void framebuffer_size_callback(GLFWwindow* window, int width, int height)
	{
		glViewport(0, 0, width, height);
	}

	//!GLFW keyboard callback
	void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
	{
		//!Close the window if the ESC key was pressed
		if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
			glfwSetWindowShouldClose(window, GL_TRUE);
		if(key == GLFW_KEY_LEFT)
			transformer.position_x +=1;
		if(key == GLFW_KEY_RIGHT)
			transformer.position_x -= 1;
		if(key == GLFW_KEY_UP)
			transformer.position_z += 1;
		if(key == GLFW_KEY_DOWN)
			transformer.position_z -= 1;
		if(key == GLFW_KEY_P)
			cout<<transformer.position_x<<" "<<transformer.position_y<<endl;
	}
};


void Camera(int CameraMode){
	if(CameraMode == 0)
		gluLookAt(transformer.position_x-10, 9.1, transformer.position_z, 
			transformer.position_x, 2, transformer.position_z, 
			0,1,0);
	else 
		cout <<"New Camera Mode" <<endl;
}