#include "transformer.hpp"

GLuint LoadTexture(const char* pic)
{
	unsigned char header[54]; // Each BMP file begins by a 54-bytes header
	unsigned int dataPos;		// Position in the file where the actual data begins
	unsigned int width, height;
	unsigned int imageSize;	// = width*height*3

	unsigned char * data;
	FILE * file = fopen(pic,"rb");
	fread(header, 1, 54, file);
	dataPos		= *(int*)&(header[0x0A]);
	imageSize	= *(int*)&(header[0x22]);
	width			= *(int*)&(header[0x12]);
	height		= *(int*)&(header[0x16]);
	data = new unsigned char [imageSize];
	fread(data,1,imageSize,file);
	fclose(file);

	GLuint textureID;
	glGenTextures(1, &textureID);
	glBindTexture(GL_TEXTURE_2D, textureID);
	glTexImage2D(GL_TEXTURE_2D, 0,GL_RGB, width, height, 0, GL_BGR, GL_UNSIGNED_BYTE, data);

	glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
	glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	free(data);
	return textureID;
}

void struct_transformer::draw(){
	//	Clear screen and Z-buffer
	glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);

	// Reset transformations
	glLoadIdentity();

	//glScalef( 1, 1, -1);
	glTranslatef(0,0.4,0);

	//glCallList(Torso);
	glPushMatrix();
		glRotatef(face_rotate_x, 1.0, 0.0, 0.0 );
		glRotatef(face_rotate_y, 0.0, 1.0, 0.0 );
		glCallList(Face);
	glPopMatrix();
	return;

	glPushMatrix();
		glRotatef(hood_rotate_x, 1.0,0,0);
		glCallList(Hood);
		glPushMatrix();
			glColor3f(0.1,0.1,0.1);
			GLUquadricObj *quadratic;
			quadratic = gluNewQuadric();
			glTranslatef(-0.28,0,0);

			glRotatef(90.0, 0.0, 1.0, 0.0);
			glRotatef(wheel_turn,-1,0,0);
			glRotatef(wheel_rotate,0,0,1);
			gluCylinder(quadratic,0.1,0.1,0.1,32,32);
			gluDisk(quadratic,0,0.1,32,32);

		glPopMatrix();

		glPushMatrix();
			glColor3f(0.1,0.1,0.1);
			quadratic = gluNewQuadric();
			glTranslatef(0.28,0,0);

			glRotatef(90.0, 0.0, -1.0, 0.0);
			glRotatef(wheel_turn,1,0,0);//
			glRotatef(wheel_rotate,0,0,1);//
			gluCylinder(quadratic,0.1,0.1,0.1,32,32);
			gluDisk(quadratic,0,0.1,32,32);
		glPopMatrix();
	glPopMatrix();

	glPushMatrix();
		glTranslatef(0,0,windshield_move);
		glTranslatef(0,-0.2,0);
		glTranslatef(0,0.19,-0.3);
		glRotatef(windshield_full_rotate, 1,0,0);
		glTranslatef(0,-0.19,0.3);

		glCallList(Windshield);

		glPushMatrix();

			glTranslatef(0.21,0.1,-0.15);
			glRotatef(windshield_left_door,0,0,1);
			glTranslatef(-0.21,-0.1,0.15);
			glCallList(LeftDoor);
			glPopMatrix();

			glTranslatef(-0.21,0.1,-0.3);
			glRotatef(windshield_right_door,0,0,-1);
			glTranslatef(0.21,-0.1,0.3);
			glCallList(RightDoor);

		glPopMatrix();
	glPopMatrix();

	glPushMatrix();
		glTranslatef(-0.12999,0,-0.001);
		glTranslatef(-0.09,0,0);
		glRotatef(left_shoulder_angle,0,0,-1);
		glTranslatef(0.09,0,0);
		glCallList(ShoulderJoint);

		glPushMatrix();
			glTranslatef(0,-0.14,0);
			glRotatef(left_upper_arm_x,1,0,0);
			glRotatef(left_upper_arm_y,0,1,0);
			glRotatef(left_upper_arm_z,0,0,1);
			glCallList(Hand);

			glPushMatrix();
				glTranslatef(0,-0.27,0);
				glRotatef(left_lower_arm_x,1,0,0);
				glRotatef(left_lower_arm_y,0,1,0);
				glRotatef(left_lower_arm_z,0,0,1);
				glCallList(Hand);
			glPopMatrix();
		glPopMatrix();
	glPopMatrix();


	glPushMatrix();
		glTranslatef(0.12999,0,-0.001);
		glTranslatef(0.09,0,0);
		glRotatef(right_shoulder_angle,0,0,1);
		glTranslatef(-0.09,0,0);
		glCallList(ShoulderJoint);

		glPushMatrix();
			glTranslatef(0,-0.14,0);
			glRotatef(right_upper_arm_x,1,0,0);
			glRotatef(right_upper_arm_y,0,1,0);
			glRotatef(right_upper_arm_z,0,0,1);
			glCallList(Hand);

			glPushMatrix();
				glTranslatef(0,-0.27,0);
				glColor3f(0.3,0.9,0.8);
				glRotatef(right_lower_arm_x,1,0,0);
				glRotatef(right_lower_arm_y,0,1,0);
				glRotatef(right_lower_arm_z,0,0,1);
				glCallList(Hand);
			glPopMatrix();
		glPopMatrix();
	glPopMatrix();

	glPushMatrix();
		glTranslatef(0,0,windshield_move);//we are moving both the windshield and backbone by the same amount
		glCallList(BackBone);
	glPopMatrix();

	glPushMatrix();
		//Right leg
		glTranslatef(-0.11999,-0.5,0);
		glRotatef(right_thigh_angle,0,0,1);
		glTranslatef(0,0.5,0);
		//glCallList(Thigh);

		glTranslatef(0,0,leg_translate);

		glTranslatef(0,-0.7,-0.4);
		glRotatef(right_knee_angle,-1,0,0);
		glTranslatef(0,0.7,0.4);
		glCallList(Leg);

		glTranslatef(0,0,foot_move);
		glTranslatef(0,-1.1,-0.2);
		glRotatef(right_foot_angle,-1,0,0);
		glTranslatef(0,1.1,0.2);
		glCallList(Foot);

		glPushMatrix();

			glColor3f(0.1,0.1,0.1);
			//GLUquadricObj *quadratic;
			quadratic = gluNewQuadric();
			//glRotatef(wheel_turn,0,0,1);
			glTranslatef(-0.15,-0.75,0);
			glRotatef(90.0, 0.0, 1.0, 0.0);
			glRotatef(wheel_rotate,0,0,1);
			gluCylinder(quadratic,0.1,0.1,0.1,32,32);
			gluDisk(quadratic,0,0.1,32,32);

		glPopMatrix();
	glPopMatrix();

	glPushMatrix();
		//Left leg
		glTranslatef(0.11999,-0.5,0);
		glRotatef(left_thigh_angle,0,0,-1);
		glTranslatef(0,0.5,0);
		//glCallList(Thigh);

		glTranslatef(0,0,leg_translate);

		glTranslatef(0,-0.7,-0.4);
		glRotatef(left_knee_angle,-1,0,0);
		glTranslatef(0,0.7,0.4);
		glCallList(Leg);

		glTranslatef(0,0,foot_move);
		glTranslatef(0,-1.1,-0.2);
		glRotatef(left_foot_angle,-1,0,0);
		glTranslatef(0,1.1,0.2);
		glCallList(Foot);

		glPushMatrix();
			glColor3f(0.1,0.1,0.1);
			quadratic = gluNewQuadric();
			glTranslatef(0.15,-0.75,0);
			glRotatef(90.0, 0.0, -1.0, 0.0);
			glRotatef(wheel_rotate,0,0,1);
			gluCylinder(quadratic,0.1,0.1,0.1,32,32);
			gluDisk(quadratic,0,0.1,32,32);

		glPopMatrix();
	glPopMatrix();
}

void ListFace()
{
	glNewList(Face, GL_COMPILE);
		glColor3f(0.8,0,0);
		glBegin(GL_QUAD_STRIP);
			glVertex3f(-0.1,0.2,-0.001);
			glVertex3f(-0.1,0,-0.001);
			glVertex3f(0.1,0.2,-0.001);
			glVertex3f(0.1,0,-0.001);
			glVertex3f(0.1,0.2,-0.2);
			glVertex3f(0.1,0,-0.2);
			glVertex3f(-0.1,0.2,-0.2);
			glVertex3f(-0.1,0,-0.2);
			glVertex3f(-0.1,0.2,-0.001);
			glVertex3f(-0.1,0,-0.001);
		glEnd();


		glColor3f(0,0,0);
		glBegin(GL_LINE_LOOP);
			glVertex3f(-0.1,0.2,-0.001);
			glVertex3f(-0.1,0,-0.001);
			glVertex3f(0.1,0,-0.001);
			glVertex3f(0.1,0.2,-0.001);		
		glEnd();
		glBegin(GL_LINE_LOOP);
			glVertex3f(0.1,0.2,-0.2);
			glVertex3f(0.1,0,-0.2);
			glVertex3f(-0.1,0,-0.2);
			glVertex3f(-0.1,0.2,-0.2);
			
		glEnd();


		glColor3f(0,1,0);
		glBegin(GL_QUADS);
			glVertex3f(-0.1,0.2,-0.001);
			glVertex3f(0.1,0.2,-0.001);
			glVertex3f(0.1,0.2,-0.2);
			glVertex3f(-0.1,0.2,-0.2);
		glEnd();
		glColor3f(0,1,0);
		glBegin(GL_QUADS);
			glVertex3f(-0.1,0,-0.001);
			glVertex3f(-0.1,0,-0.2);
			glVertex3f(0.1,0,-0.2);
			glVertex3f(0.1,0,-0.001);
		glEnd();

    glEndList();
}

void ListHood()
{
	glNewList(Hood, GL_COMPILE);
		glColor3f(0.5,0.75,0);
		glBegin(GL_QUADS);
			glVertex3f(-0.21,0.2,-0.3);
			glVertex3f(-0.21,0,-0.3);
			glVertex3f(-0.1,0,-0.3);
			glVertex3f(-0.1,0.2,-0.3);
		glEnd();
		glBegin(GL_QUADS);
			glVertex3f(0.21,0.2,-0.3);
			glVertex3f(0.1,0.2,-0.3);
			glVertex3f(0.1,0,-0.3);
			glVertex3f(0.21,0,-0.3);
		glEnd();
		glBegin(GL_QUADS);
			glVertex3f(0.1,0.2,-0.3);
			glVertex3f(0.1,0,-0.3);
			glVertex3f(0.1,0,-0);
			glVertex3f(0.1,0.2,-0);
		glEnd();
		glBegin(GL_QUADS);
			glVertex3f(-0.1,0.2,-0.3);
			glVertex3f(-0.1,0,-0.3);
			glVertex3f(-0.1,0,-0);
			glVertex3f(-0.1,0.2,-0);
		glEnd();
		glBegin(GL_QUADS);
			glVertex3f(-0.21,0.5,0);
			glVertex3f(-0.21,0,0);
			glVertex3f(0.21,0,0);
			glVertex3f(0.21,0.5,0);
		glEnd();
		glBegin(GL_QUADS);
			glVertex3f(-0.21,0.5,0);
			glVertex3f(0.21,0.5,0);
			glVertex3f(0.21,0.5,-0.15);
			glVertex3f(-0.21,0.5,-0.15);			
		glEnd();
		glColor3f(0.5,0,0.1);
		glBegin(GL_QUADS);
			glVertex3f(-0.21,0.5,-0.15);
			glVertex3f(0.21,0.5,-0.15);
			glVertex3f(0.21,0.2,-0.3);
			glVertex3f(-0.21,0.2,-0.3);
		glEnd();
		glBegin(GL_POLYGON);
			glVertex3f(-0.21,0,0);
			glVertex3f(-0.21,0.5,0);
			glVertex3f(-0.21,0.5,-0.15);
			glVertex3f(-0.21,0.2,-0.3);
			glVertex3f(-0.21,0,-0.3);
			glVertex3f(-0.21,0,0);
		glEnd();
		glBegin(GL_POLYGON);
			glVertex3f(0.21,0,0);
			glVertex3f(0.21,0.5,0);
			glVertex3f(0.21,0.5,-0.15);
			glVertex3f(0.21,0.2,-0.3);
			glVertex3f(0.21,0,-0.3);
			glVertex3f(0.21,0,0);
		glEnd();

		
	glEndList();
}

void ListWindshield()
{
	glNewList(Windshield, GL_COMPILE);
		/*glColor3f(0,0,0);
		glBegin(GL_QUADS);
			glVertex3f(-0.21,0,-0.3);
			glVertex3f(0.21,0,-0.3);
			glVertex3f(0.21,-0.19,-0.5);
			glVertex3f(-0.21,-0.19,-0.5);
		glEnd();
		glColor3f(1,1,0);
		glBegin(GL_LINE_LOOP);
			glVertex3f(-0.21,0,-0.3);
			glVertex3f(0.21,0,-0.3);
			glVertex3f(0.21,-0.19,-0.5);
			glVertex3f(-0.21,-0.19,-0.5);
		glEnd();*/
		glColor3f(1,1,0);
		glBegin(GL_QUADS);
			glVertex3f(-0.21,0,-0.3);
			glVertex3f(0.21,0,-0.3);
			glVertex3f(0.21,-0.19,-0.5);
			glVertex3f(-0.21,-0.19,-0.5);
		glEnd();
		glColor3f(0,0,0);
		glBegin(GL_QUADS);
			glVertex3f(-0.2,0.01,-0.31);
			glVertex3f(0.2,0.01,-0.31);
			glVertex3f(0.2,-0.18,-0.49);
			glVertex3f(-0.2,-0.18,-0.49);
		glEnd();

		glColor3f(1,1,0);
		glBegin(GL_QUADS);
			glVertex3f(-0.21,0,-0.3);
			glVertex3f(-0.21,0.19,-0.3);
			glVertex3f(0.21,0.19,-0.3);
			glVertex3f(0.21,0,-0.3);
		glEnd();
		glBegin(GL_TRIANGLES);
			glVertex3f(-0.21,0,-0.3);
			glVertex3f(-0.21,0.095,-0.2);
			glVertex3f(-0.21,0.19,-0.3);
		glEnd();
		glBegin(GL_TRIANGLES);
			glVertex3f(0.21,0,-0.3);
			glVertex3f(0.21,0.095,-0.2);
			glVertex3f(0.21,0.19,-0.3);
		glEnd();
	glEndList();
}

void ListLeftDoor()
{
	glNewList(LeftDoor, GL_COMPILE);
		glColor3f(1,1,0);
		glBegin(GL_POLYGON);
			glVertex3f(0.21,0.1,-0.2);
			glVertex3f(0.21,-0.19,-0.5);
			glVertex3f(0.21,-0.5,-0.5);
			glVertex3f(0.21,-0.5,-0.1);
			glVertex3f(0.21,0.1,-0.1);
			glVertex3f(0.21,0.1,-0.2);
		glEnd();

		glColor3f(0,0,0);
		glBegin(GL_LINE_LOOP);
			glVertex3f(0.21,0.1,-0.2);
			glVertex3f(0.21,-0.19,-0.5);
			glVertex3f(0.21,-0.5,-0.5);
			glVertex3f(0.21,-0.5,-0.1);
			glVertex3f(0.21,0.1,-0.1);
			glVertex3f(0.21,0.1,-0.2);
		glEnd();

		glColor3f(0,0,0);
		glBegin(GL_QUADS);
			glVertex3f(0.211,-0.19,-0.48);
			glVertex3f(0.211,-0.48,-0.48);
			glVertex3f(0.211,-0.48,-0.3);
			glVertex3f(0.211,-0.02,-0.3);
			
		glEnd();
	glEndList();
}

void ListRightDoor()
{
	glNewList(RightDoor, GL_COMPILE);
		glColor3f(1,1,0);
		glBegin(GL_POLYGON);
			glVertex3f(-0.21,0.1,-0.2);
			glVertex3f(-0.21,-0.19,-0.5);
			glVertex3f(-0.21,-0.5,-0.5);
			glVertex3f(-0.21,-0.5,-0.1);
			glVertex3f(-0.21,0.1,-0.1);
			glVertex3f(-0.21,0.1,-0.2);
		glEnd();

		glColor3f(0,0,0);
		glBegin(GL_LINE_LOOP);
			glVertex3f(-0.21,0.1,-0.2);
			glVertex3f(-0.21,-0.19,-0.5);
			glVertex3f(-0.21,-0.5,-0.5);
			glVertex3f(-0.21,-0.5,-0.1);
			glVertex3f(-0.21,0.1,-0.1);
			glVertex3f(-0.21,0.1,-0.2);
		glEnd();

		glColor3f(0,0,0);
		glBegin(GL_QUADS);
			glVertex3f(-0.211,-0.19,-0.48);
			glVertex3f(-0.211,-0.48,-0.48);
			glVertex3f(-0.211,-0.48,-0.3);
			glVertex3f(-0.211,-0.02,-0.3);
			
		glEnd();
	glEndList();
}

void ListShoulderJoint()
{
	glNewList(ShoulderJoint, GL_COMPILE);
		glColor3f(0.1,0.3,0.4);
		glBegin(GL_QUAD_STRIP);
			glVertex3f(-0.07,0,-0.001);
			glVertex3f(-0.07,-0.14,-0.001);
			glVertex3f(0.07,0,-0.001);
			glVertex3f(0.07,-0.14,-0.001);
			glVertex3f(0.07,0,-0.1399);
			glVertex3f(0.07,-0.14,-0.1399);
			glVertex3f(-0.07,0,-0.1399);
			glVertex3f(-0.07,-0.14,-0.1399);
			glVertex3f(-0.07,0,-0.001);
			glVertex3f(-0.07,-0.14,-0.001);
		glEnd();
		glBegin(GL_QUADS);
			glVertex3f(-0.07,0,-0.001);
			glVertex3f(0.07,0,-0.001);
			glVertex3f(0.07,0,-0.1399);
			glVertex3f(-0.07,0,-0.1399);
		glEnd();
		glBegin(GL_QUADS);
			glVertex3f(-0.07,-0.14,-0.001);
			glVertex3f(-0.07,-0.14,-0.1399);
			glVertex3f(0.07,-0.14,-0.1399);
			glVertex3f(0.07,-0.14,-0.001);
		glEnd();
	glEndList();
}

void ListHand()
{
	glNewList(Hand, GL_COMPILE);
		glColor3f(0.7,0.7,0.1);
		glBegin(GL_QUAD_STRIP);
			glVertex3f(-0.08,0,0);
			glVertex3f(-0.08,-0.27,0);
			glVertex3f(0.08,0,0);
			glVertex3f(0.08,-0.27,0);
			glVertex3f(0.08,0,-0.16);
			glVertex3f(0.08,-0.27,-0.16);
			glVertex3f(-0.08,0,-0.16);
			glVertex3f(-0.08,-0.27,-0.16);
			glVertex3f(-0.08,0,0);
			glVertex3f(-0.08,-0.27,0);
		glEnd();
		/*glColor3f(0,0,0);
		glBegin(GL_LINE_LOOP);
			glVertex3f(-0.08,0,0);
			glVertex3f(-0.08,-0.27,0);
			glVertex3f(0.08,-0.27,0);
			glVertex3f(0.08,0,0);
			
			glVertex3f(0.08,0,-0.16);
			glVertex3f(0.08,-0.27,-0.16);
			glVertex3f(-0.08,-0.27,-0.16);
			glVertex3f(-0.08,0,-0.16);
			

			//glVertex3f(-0.08,0,0);
			//glVertex3f(-0.08,-0.27,0);
		glEnd();
		*/
		glColor3f(0.7,0.7,0.1);
		glBegin(GL_QUADS);
			glVertex3f(-0.08,0,0);
			glVertex3f(0.08,0,0);
			glVertex3f(0.08,0,-0.16);
			glVertex3f(-0.08,0,-0.16);
		glEnd();
		glBegin(GL_QUADS);
			glVertex3f(-0.08,-0.27,0);
			glVertex3f(-0.08,-0.27,-0.16);
			glVertex3f(0.08,-0.27,-0.16);
			glVertex3f(0.08,-0.27,0);
		glEnd();
	glEndList();
}

void ListBackBone()
{
	glNewList(BackBone, GL_COMPILE);
		glColor3f(0,0,1);
		glBegin(GL_QUAD_STRIP);
			glVertex3f(0.20999,-0.14,-0.2999);
			glVertex3f(0.20999,-0.14,-0.1);
			glVertex3f(0.20999,0,-0.2999);
			glVertex3f(0.20999,0,-0.1);
			glVertex3f(-0.20999,0,-0.2999);
			glVertex3f(-0.20999,0,-0.1);
			glVertex3f(-0.20999,-0.14,-0.2999);
			glVertex3f(-0.20999,-0.14,-0.1);
			glVertex3f(0.20999,-0.14,-0.2999);
			glVertex3f(0.20999,-0.14,-0.1);
		glEnd();
		glColor3f(1,1,0);
		glBegin(GL_QUADS);
			glVertex3f(0.20999,0,-0.2999);
			glVertex3f(0.20999,-0.14,-0.2999);
			glVertex3f(-0.20999,-0.14,-0.2999);
			glVertex3f(-0.20999,0,-0.2999);
		glEnd();
		glBegin(GL_QUADS);
			glVertex3f(0.20999,-0.14,-0.1);
			glVertex3f(0.20999,0,-0.1);
			glVertex3f(-0.20999,0,-0.1);
			glVertex3f(-0.20999,-0.14,-0.1);
		glEnd();



		glColor3f(0,0,0);
		glBegin(GL_LINE_LOOP);
			glVertex3f(0.20999,0,-0.2999);
			glVertex3f(0.20999,-0.14,-0.2999);
			glVertex3f(-0.20999,-0.14,-0.2999);
			glVertex3f(-0.20999,0,-0.2999);
		glEnd();

		glBegin(GL_LINE_LOOP);
			glVertex3f(-0.2099,-0.39001,-0.5);
			glVertex3f(0.2099,-0.39001,-0.5);
			glVertex3f(0.2099,-0.7,-0.5);
			glVertex3f(-0.2099,-0.7,-0.5);
		glEnd();
		glBegin(GL_LINE_LOOP);
			glVertex3f(-0.2099,-0.2001,-0.3);
			glVertex3f(0.2099,-0.2001,-0.3);
			glVertex3f(0.2099,-0.39001,-0.5);
			glVertex3f(-0.2099,-0.39001,-0.5);
		glEnd();
		/*glBegin(GL_LINE_LOOP);
			glVertex3f(0.20999,-0.14,-0.1);
			glVertex3f(0.20999,0,-0.1);
			glVertex3f(-0.20999,0,-0.1);
			glVertex3f(-0.20999,-0.14,-0.1);
		glEnd();
		glBegin(GL_LINE_LOOP);
			glVertex3f(0.21,-0.2001,-0.2999);
			glVertex3f(-0.21,-0.2001,-0.2999);
			glVertex3f(-0.21,-0.1,-0.2999);
			glVertex3f(0.21,-0.1,-0.2999);
		glEnd();

		*/



		glColor3f(1,1,0);
		glBegin(GL_QUADS);
			glVertex3f(0.2099,-0.2001,-0.2999);
			glVertex3f(-0.2099,-0.2001,-0.2999);
			glVertex3f(-0.2099,-0.1,-0.2999);
			glVertex3f(0.2099,-0.1,-0.2999);
		glEnd();

		glBegin(GL_QUADS);
			glVertex3f(-0.2099,-0.2001,-0.3);
			glVertex3f(0.2099,-0.2001,-0.3);
			glVertex3f(0.2099,-0.39001,-0.5);
			glVertex3f(-0.2099,-0.39001,-0.5);
		glEnd();

		glBegin(GL_QUADS);
			glVertex3f(-0.2099,-0.39001,-0.5);
			glVertex3f(0.2099,-0.39001,-0.5);
			glVertex3f(0.2099,-0.7,-0.5);
			glVertex3f(-0.2099,-0.7,-0.5);
		glEnd();

		glBegin(GL_POLYGON);
			glVertex3f(-0.20998,-0.7,-0.5);
			glVertex3f(-0.20998,-0.7,-0.2);
			glVertex3f(-0.20998,-0.15,-0.2);
			glVertex3f(-0.20998,-0.15,-0.3);
			glVertex3f(-0.20998,-0.2,-0.3);
			glVertex3f(-0.20998,-0.39,-0.5);
		glEnd();
		glBegin(GL_POLYGON);
			glVertex3f(0.20998,-0.7,-0.5);
			glVertex3f(0.20998,-0.7,-0.2);
			glVertex3f(0.20998,-0.15,-0.2);
			glVertex3f(0.20998,-0.15,-0.3);
			glVertex3f(0.20998,-0.2,-0.3);
			glVertex3f(0.20998,-0.39,-0.5);
		glEnd();
		glBegin(GL_QUADS);
			glVertex3f(0.20998,-0.15,-0.2);
			glVertex3f(-0.20998,-0.15,-0.2);
			glVertex3f(-0.20998,-0.7,-0.2);
			glVertex3f(0.20998,-0.7,-0.2);
		glEnd();

	glEndList();
}

void ListThigh()
{
	glNewList(Thigh, GL_COMPILE);
		glColor3f(0.8,0,0.8);
		glBegin(GL_QUADS);
			glVertex3f(-0.09,-0.5,-0.3);
			glVertex3f(0.09,-0.5,-0.3);
			glVertex3f(0.09,-0.7,-0.3);
			glVertex3f(-0.09,-0.7,-0.3);
		glEnd();
		glBegin(GL_QUADS);
			glVertex3f(-0.09,-0.7,-0.16);
			glVertex3f(0.09,-0.7,-0.16);
			glVertex3f(0.09,-0.5,-0.16);
			glVertex3f(-0.09,-0.5,-0.16);			
		glEnd();
		glBegin(GL_QUAD_STRIP);
			glVertex3f(0.09,-0.5,-0.3);
			glVertex3f(0.09,-0.5,-0.16);
			glVertex3f(0.09,-0.7,-0.3);
			glVertex3f(0.09,-0.7,-0.16);
			glVertex3f(-0.09,-0.7,-0.3);
			glVertex3f(-0.09,-0.7,-0.16);
			glVertex3f(-0.09,-0.5,-0.3);
			glVertex3f(-0.09,-0.5,-0.16);
			glVertex3f(0.09,-0.5,-0.3);
			glVertex3f(0.09,-0.5,-0.16);
		glEnd();
	glEndList();
}

void ListLeg()
{
	glNewList(Leg, GL_COMPILE);
	glColor3f(0.5,0.5,0);//0.39
		
		glBegin(GL_QUADS);
			glVertex3f(-0.09,-0.7,-0.5);
			glVertex3f(0.09,-0.7,-0.5);
			glVertex3f(0.09,-1.1,-0.3);
			glVertex3f(-0.09,-1.1,-0.3);
		glEnd();
		glBegin(GL_QUADS);
			glVertex3f(-0.09,-1.1,-0.3);
			glVertex3f(0.09,-1.1,-0.3);
			glVertex3f(0.09,-1.1,-0.2);
			glVertex3f(-0.09,-1.1,-0.2);
		glEnd();
		glBegin(GL_QUADS);
			glVertex3f(-0.09,-1.1,-0.2);
			glVertex3f(0.09,-1.1,-0.2);
			glVertex3f(0.09,-0.7,-0.2);
			glVertex3f(-0.09,-0.7,-0.2);
		glEnd();
		glBegin(GL_QUADS);
			glVertex3f(-0.09,-0.7,-0.5);
			glVertex3f(-0.09,-1.1,-0.3);
			glVertex3f(-0.09,-1.1,-0.2);
			glVertex3f(-0.09,-0.7,-0.2);
		glEnd();
		glBegin(GL_QUADS);
			glVertex3f(0.09,-0.7,-0.5);
			glVertex3f(0.09,-1.1,-0.3);
			glVertex3f(0.09,-1.1,-0.2);
			glVertex3f(0.09,-0.7,-0.2);
		glEnd();
	glEndList();
}

void ListFoot()
{
	glNewList(Foot, GL_COMPILE);
		glColor3f(0.1,0.1,0.8);
		glBegin(GL_QUAD_STRIP);
			glVertex3f(-0.09,-0.7,-0.2);
			glVertex3f(-0.09,-1.1,-0.2);
			glVertex3f(0.09,-0.7,-0.2);
			glVertex3f(0.09,-1.1,-0.2);
			glVertex3f(0.09,-0.7,0);
			glVertex3f(0.09,-1.1,0);
			glVertex3f(-0.09,-0.7,0);
			glVertex3f(-0.09,-1.1,0);
			glVertex3f(-0.09,-0.7,-0.2);
			glVertex3f(-0.09,-1.1,-0.2);			
		glEnd();
		glBegin(GL_QUADS);
			glVertex3f(-0.09,-0.7,-0.2);
			glVertex3f(-0.09,-0.7,0);
			glVertex3f(0.09,-0.7,0);
			glVertex3f(0.09,-0.7,-0.2);
		glEnd();
		glBegin(GL_QUADS);
			glVertex3f(-0.09,-1.1,-0.2);
			glVertex3f(0.09,-1.1,-0.2);
			glVertex3f(0.09,-1.1,0);
			glVertex3f(-0.09,-1.1,0);
		glEnd();
	glEndList();
}


void struct_transformer::GenLists()
{
	ListFace();
	ListHood();
	ListWindshield();
	ListLeftDoor();
	ListRightDoor();
	ListShoulderJoint();
	ListHand();
	ListBackBone();
	ListLeg();
	ListThigh();
	ListFoot();
}