from hiperware.outliers.image import *
from hiperwareLibrary import *
from random import randrange
import sys

DEVELOPER_ID = "rohan@hiperware.com"
QUESTION_CATEGORY = {
            "grade": "First",
            "subject": "Math",
            "skill_group": "Geometry",
            "skill": "Defining Characteristics of Shapes"
            }
shape=[['square','square'], ['rectangle','rectangle'],['half_triangle', 'trapezoid'],['half_trapezoid','trapezoid'],['semicircle','semicircle']]
shapeName= ['rectangle', 'square', 'triangle', 'trapezoid', 'circle']
count =1
n= raw_input('How many questions you want to generate? (Better if a multiple of 360) : ')
n= int(n)+1

for a in range(len(shape)):
    for b in range(len(shape)):
        if b==a:
            continue
        for c in range(len(shape)):
            if c==a or c==b:
                continue
            for d in range(len(shape)):
                if count==n:
                    sys.exit()
                if d==a or d==b or d==c:
                    continue
##                DRAWING IMAGES HERE
                ra=rb=rc=rd=0
                if (a==0) or (b==0) or (c==0) or (d==0):
                    (r1,r2,r3)= selectColour()
                    drawSquare(r1,r2,r3)
                if (a==1) or (b==1) or (c==1) or (d==1):
                    (r1,r2,r3)= selectColour()
                    drawRectangle(r1,r2,r3)
                if (a==4) or (b==4) or (c==4) or (d==4):
                    (r1,r2,r3)= selectColour()
                    angle=randrange(360)
                    drawSemicircle(r1,r2,r3,angle)
                
                if a==2:
                    ra=randrange(2)
                    (r1,r2,r3)= selectColour()
                    if ra==0:
                        drawHalfTriangle(r1,r2,r3)
                    else:
                        drawTrapezoid(r1,r2,r3)
                elif b==2:
                    rb=randrange(2)
                    (r1,r2,r3)= selectColour()
                    if rb==0:
                        drawHalfTriangle(r1,r2,r3)
                    else:
                        drawTrapezoid(r1,r2,r3)
                elif c==2:
                    rc=randrange(2)
                    (r1,r2,r3)= selectColour()
                    if rc==0:
                        drawHalfTriangle(r1,r2,r3)
                    else:
                        drawTrapezoid(r1,r2,r3)
                elif d==2:
                    rd=randrange(2)
                    (r1,r2,r3)= selectColour()
                    if rd==0:
                        drawHalfTriangle(r1,r2,r3)
                    else:
                        drawTrapezoid(r1,r2,r3)

                if a==3:
                    ra=randrange(2)
                    (r1,r2,r3)= selectColour()
                    if ra==0:
                        drawHalfTrapezoid(r1,r2,r3)
                    else:
                        drawTrapezoid(r1,r2,r3)
                elif b==3:
                    rb=randrange(2)
                    (r1,r2,r3)= selectColour()
                    if rb==0:
                        drawHalfTrapezoid(r1,r2,r3)
                    else:
                        drawTrapezoid(r1,r2,r3)
                elif c==3:
                    rc=randrange(2)
                    (r1,r2,r3)= selectColour()
                    if rc==0:
                        drawHalfTrapezoid(r1,r2,r3)
                    else:
                        drawTrapezoid(r1,r2,r3)
                elif d==3:
                    rd=randrange(2)
                    (r1,r2,r3)= selectColour()
                    if rd==0:
                        drawHalfTrapezoid(r1,r2,r3)
                    else:
                        drawTrapezoid(r1,r2,r3)
##                print(shape[a][ra] + ', ' + shape[b][rb] + ', ' + shape[c][rc] + ', ' + shape[d][rd])
                builder = Builder(DEVELOPER_ID, QUESTION_CATEGORY)
                builder.text("Which is the half of a " + shapeName[a] + " ?\n", center=True,  color=RED_TEXT_COLOR)
                e= randrange(4)
                ptr=0
                for f in range(4):
                    if f==e:
                        checkbox_data = builder.Block()
                        checkbox_data.picture(shape[a][ra], size=LARGE_PICTURE_SIZE)
                        builder.checkbox(checkbox_data, True, center= True)

                    else:
                        if ptr==0:
                            checkbox_data = builder.Block()
                            checkbox_data.picture(shape[b][rb], size=LARGE_PICTURE_SIZE)
                            builder.checkbox(checkbox_data, False, center= True)
                            ptr+=1
                            continue

                        if ptr==1:
                            checkbox_data = builder.Block()
                            checkbox_data.picture(shape[c][rc], size=LARGE_PICTURE_SIZE)
                            builder.checkbox(checkbox_data, False, center= True)
                            ptr+=1
                            continue

                        if ptr==2:
                            checkbox_data = builder.Block()
                            checkbox_data.picture(shape[d][rd], size=LARGE_PICTURE_SIZE)
                            builder.checkbox(checkbox_data, False, center= True)
                            ptr+=1
                            continue
                
                builder.save("./output", "G1_095- " + str(count))
                print(count)
                count+=1

##                DELETE IMAGES HERE
                deleteSquare()
                deleteHalfTriangle()
                deleteTrapezoid()
                deleteHalfTrapezoid()
                deleteSemicircle()
                
