from hiperware.outliers.image import *
from hiperwareLibrary import *
from random import randrange
import sys

DEVELOPER_ID = "rohan@hiperware.com"
QUESTION_CATEGORY = {
            "grade": "First",
            "subject": "Math",
            "skill_group": "Geometry",
            "skill": "Defining Characteristics of Shapes"
            }
shape=['rectangle', 'square','quarter_circle']
shapeName= ['rectangle', 'square', 'circle']
count =1
n= raw_input('How many questions you want to generate? (Better if a multiple of 360) : ')
n= int(n)+1

while True:
    for a in range(len(shape)):
        for b in range(8):
            if b==a:
                continue
            for c in range(8):
                if c==a or c==b:
                    continue
                for d in range(8):
                    if count==n:
                        sys.exit()
                    if d==a or d==b or d==c:
                        continue
                    isC=isD=False
                    builder = Builder(DEVELOPER_ID, QUESTION_CATEGORY)
                    builder.text("Which is the quarter of a " + shapeName[a] + " ?\n", center=True,  color=RED_TEXT_COLOR)
                    e= randrange(4)
                    for f in range(4):
                        if f==e:
                            (r1,r2,r3)= selectColour()
                            drawSingle(r1,r2,r3,a,True,builder)
                        else:
                            if isD:
                                (r1,r2,r3)= selectColour()
                                drawSingle(r1,r2,r3,d,False,builder)
                            elif isC:
                                (r1,r2,r3)= selectColour()
                                drawSingle(r1,r2,r3,c,False,builder)
                                isD=True
                            else:
                                (r1,r2,r3)= selectColour()
                                drawSingle(r1,r2,r3,b,False,builder)
                                isC=True

                    builder.save("./output", "G1_096- " + str(count))
                    print(count)
                    count+=1

## DELETE IMAGES HERE ##
deleteSquare()
deleteRectangle()
deleteQuarterCircle()
