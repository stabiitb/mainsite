from hiperware.outliers.image import *
from hiperwareLibrary import *
from random import randrange
import sys

DEVELOPER_ID = "rohan@hiperware.com"
QUESTION_CATEGORY = {
            "grade": "First",
            "subject": "Math",
            "skill_group": "Geometry",
            "skill": "Defining Characteristics of Shapes"
            }
count =1
n= raw_input('How many questions you want to generate? (Better if a multiple of 360) : ')
n= int(n)+1

for a in range(5):
    for b in range(5):
        if b==a:
            continue
        for c in range(5):
            if c==a or c==b:
                continue
            for d in range(5):
                if count==n:
                    sys.exit()
                if d==a or d==b or d==c:
                    continue
                isC=isD= False
                builder = Builder(DEVELOPER_ID, QUESTION_CATEGORY)
                builder.text("Which is divided into two equal sections?\n", center=True,  color=RED_TEXT_COLOR)
                r= randrange(4)
                ptr=0
                for f in range(4):
                    if f==r:
                        (r1,r2,r3)= selectColour()
                        drawEqualHalves(r1,r2,r3,a,True, builder)
                    else:
                        (r1,r2,r3)= selectColour()
                        if isD:
                            drawUnequalHalves(r1,r2,r3,d,False, builder)
                        elif isC:
                            drawUnequalHalves(r1,r2,r3,c,False, builder)
                            isD=True
                        else:
                            drawUnequalHalves(r1,r2,r3,b,False, builder)
                            isC=True
                builder.save("./output", "G1_098- " + str(count))
                print(count)
                count+=1
