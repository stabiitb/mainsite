import inflect
import random

#import the Rendering API package
from hiperware.outliers.image import *

# developer ID received from Hiperware
DEVELOPER_ID = "sritanu@hiperware.com"

# question category (all the fields are required)
QUESTION_CATEGORY = {
    "grade": "Second",
    "subject": "Math",
    "skill_group": "Word Problems",
    "skill": "Subtraction with images"
}

p=inflect.engine()

dict = {'1': ['balloon', 'basket', 'book', 'hat', 'jar', 'key', 'lemon', 'lemonade', 'lock', 'lollypop', 'medal', 'pencil', 'pineapple', 'plant', 'pot', 'rose', 'shell', 'toothbrush', 't-shirt', 'umbrella'],
'2': ['burger','pineapple', 'strawberry', 'lollypop', 'hotdog'],
'3': ['balloon', 'basket', 'book', 'box', 'broom', 'bucket', 'burger', 'duck', 'fish', 'hat', 'hotdog', 'jar', 'key', 'lamp', 'lemon', 'lemonade', 'lock', 'lollypop', 'medal', 'pencil', 'plant', 'pot', 'purse', 'rose', 'shell', 'snail', 'star', 'strawberry', 'toothbrush', 't-shirt', 'umbrella'],
'4': ['basket', 'cake', 'hat', 't-shirt']};


girl_names = ["Jill", "Emily", "Liz", "Naomi", "Rachel", "Leilani", "Kate", "Cassidy", "Sarah", "Jenna", "Maria", "Suzie", "Olivia", "Claire", "Lucy", "Jane", "Sydney", "Zoie", "Emma", "Julie","Maya", "Vera", "Sofia", "Clara", "Dona", "Gina", "Yuki", "Akira", "Liu", "Angela", "Amina", "Neha"]
boy_names = ["Luke", "Craig", "John", "Ben", "Mike", "Louis", "Aiden", "Isaiah", "Miles", "Henry", "Theo", "Andrew", "Caleb", "Chris", "James", "Matthew", "Peter", "Paul", "Frank", "Martin","Aamir", "Lucas", "Boris", "Yury", "Mario", "Marco", "Nobu", "Han", "Li", "Carlos", "Salim", "Rishi"]

boy_or_girl = ["girl_names","boy_names"]
he_or_she = ["She","He"]

max_questions = 400

listOfCombinations = []

def main():
	counter = 1
	for i in range(max_questions):
		flag = 0
		while flag == 0:	
			j = random.randint(0,1)
			k = random.randint(0,1)
			m = random.randint(10,30)
			n = random.randint(31,45)
			l = random.randint(0,3)
			#print j,k,m,n,l
			
			if [j,k,m,n,l] in listOfCombinations:
				continue
			else:
				listOfCombinations.append([j,k,m,n,l])
				flag = 1
			
			#print listOfCombinations
		
		generatequestion(j,k,m,n,l,counter)
		counter+=1

def generatequestion(j,k,m,n,l,z):
	# create Builder() class instance (DEVELOPER_ID and QUESTION_CATEGORY are required)
		builder = Builder(DEVELOPER_ID, QUESTION_CATEGORY)
		r = range(2,101)
		block = builder.Block()
		sentences = dict.keys()
		object_of_the_question = random.choice(dict.get(sentences[l]))

		if l==1:
			person1 = random.choice(eval(boy_or_girl[j]))
			person2 = random.choice(eval(boy_or_girl[k]))
			while person1 == person2:
				person2 = random.choice(eval(boy_or_girl[k]))
			block.text(person1+" and "+person2+" have")
			block.text(" "+str(m+n),color=GREEN_TEXT_COLOR)
			block.text(" "+p.plural(object_of_the_question)+" together.")
			block.text(" "+str(m),color=GREEN_TEXT_COLOR)
			block.text(" of those belong to "+person1+". How many "+p.plural(object_of_the_question)+" does "+person2+" have?\n")
		elif l==0:
			person1 = random.choice(eval(boy_or_girl[j]))
			person1_gender = he_or_she[j]
			block.text(person1+" had")
			block.text(" "+str(m+n),color=GREEN_TEXT_COLOR)
			block.text(" "+p.plural(object_of_the_question)+".")
			block.text(" "+person1_gender+" gave")
			block.text(" "+str(m),color=GREEN_TEXT_COLOR)
			block.text(" of them away. How many "+p.plural(object_of_the_question)+" are left?\n")
		elif l==2:
			#for j in range(2):
			person1 = random.choice(eval(boy_or_girl[j]))
			person1_gender = he_or_she[j]
			block.text(person1+" had")
			block.text(" "+str(m+n),color=GREEN_TEXT_COLOR)
			block.text(" "+p.plural(object_of_the_question)+".")
			block.text(" "+person1_gender+" ate")
			block.text(" "+str(m),color=GREEN_TEXT_COLOR)
			block.text(" of them. How many "+p.plural(object_of_the_question)+" are left?\n")
		else:
			#for j in range(2):
			person1 = random.choice(eval(boy_or_girl[j]))
			person1_gender = he_or_she[j]
			block.text(person1+" made")
			block.text(" "+str(m+n),color=GREEN_TEXT_COLOR)
			block.text(" "+p.plural(object_of_the_question)+", and sold")
			block.text(" "+str(m),color=GREEN_TEXT_COLOR)
			block.text(" at the school fair. How many "+p.plural(object_of_the_question)+" are left?\n")

		builder.block(block,center=True)

		objectToBeDrawn = object_of_the_question

		blocksImageke = []

		# 2nd block
		blockImageka = builder.Block()
		blockImageka.grid(objectToBeDrawn, (m+n)/7+1, 7, num=n+m, size=SMALLEST_PICTURE_SIZE)
		blocksImageke.append(blockImageka)

		# 1st block
		blockTextKa = builder.Block()
		blockTextKa.text(" - ")
		blocksImageke.append(blockTextKa)

		# 3rd block
		blockImageka = builder.Block()
		blockImageka.grid(objectToBeDrawn, m/7+1, 7, num=m, size=SMALLEST_PICTURE_SIZE)
		blocksImageke.append(blockImageka)


		blockImageka = builder.Block()
		blockImageka.text(" =  ? ")
		blocksImageke.append(blockImageka)

		
		builder.blocks(blocksImageke,center=True)
		
		data_list, correct_list = [], []

		correct_choice = random.randrange(0,4)

		checkbox_data_1 = builder.Block()
		checkbox_data_1.text(str(n))
		#print(m+n)
		r.remove(n)

		correct_list.append(correct_choice==0)

		checkbox_data_2 = builder.Block()
		choice2 = random.choice(r)
		checkbox_data_2.text(str(choice2))
		r.remove(choice2)	

		correct_list.append(correct_choice==1) 


		checkbox_data_3 = builder.Block()
		choice3 = random.choice(r)
		checkbox_data_3.text(str(choice3))
		r.remove(choice3)

		correct_list.append(correct_choice==2)

		checkbox_data_4 = builder.Block()
		choice4 = random.choice(r)
		checkbox_data_4.text(str(choice4))
		r.remove(choice4)

		correct_list.append(correct_choice==3)

		if correct_choice==0:
			data_list.append(checkbox_data_1)
			data_list.append(checkbox_data_2)
			data_list.append(checkbox_data_3)
			data_list.append(checkbox_data_4)
		elif correct_choice==1:
			data_list.append(checkbox_data_2)
			data_list.append(checkbox_data_1)
			data_list.append(checkbox_data_3)
			data_list.append(checkbox_data_4)
		elif correct_choice==2:
			data_list.append(checkbox_data_3)
			data_list.append(checkbox_data_2)
			data_list.append(checkbox_data_1)
			data_list.append(checkbox_data_4)
		else:
			data_list.append(checkbox_data_4)
			data_list.append(checkbox_data_3)
			data_list.append(checkbox_data_2)
			data_list.append(checkbox_data_1)
		# draw all the checkboxes
		builder.checkboxes(data_list, correct_list, cols=1)
		builder.save("./output/G2_015", "G2_015-"+str(z))

if __name__ == '__main__':
	main()